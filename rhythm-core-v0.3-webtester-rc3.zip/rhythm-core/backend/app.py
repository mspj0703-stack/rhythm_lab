from __future__ import annotations

import asyncio
import json
import mimetypes
import os
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parents[1]
ANALYZER = ROOT / "analyzer"
sys.path.insert(0, str(ANALYZER))

from chartgen.errors import ChartGenError  # noqa: E402
from chartgen.pipeline import generate_chart  # noqa: E402

RUNTIME = ROOT / ".runtime"
UPLOADS = RUNTIME / "uploads"
RESULTS = RUNTIME / "results"
EVALUATIONS = RUNTIME / "evaluations.jsonl"
for folder in (UPLOADS, RESULTS):
    folder.mkdir(parents=True, exist_ok=True)

MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "80"))
MAX_UPLOAD_BYTES = MAX_UPLOAD_MB * 1024 * 1024
MAX_AUDIO_DURATION_SEC = float(os.getenv("MAX_AUDIO_DURATION_SEC", "600"))
RUNTIME_TTL_HOURS = float(os.getenv("RUNTIME_TTL_HOURS", "6"))
ANALYZE_CONCURRENCY = max(1, int(os.getenv("ANALYZE_CONCURRENCY", "1")))
ANALYZE_SEMAPHORE = asyncio.Semaphore(ANALYZE_CONCURRENCY)
ALLOWED_EXTENSIONS = {".wav", ".mp3", ".flac", ".ogg", ".m4a", ".aac", ".webm", ".mp4"}
DIFFICULTIES = {"easy", "normal", "hard", "expert"}

app = FastAPI(title="AI Rhythm Lab", version="0.3.0-rc.3-web")


class EvaluationPayload(BaseModel):
    analysis_id: str = Field(min_length=1, max_length=64)
    song_name: str = Field(min_length=1, max_length=240)
    ratings: dict[str, int]
    comment: str = Field(default="", max_length=2000)


@app.get("/api/health")
def health() -> dict:
    return {
        "ok": True,
        "version": app.version,
        "maxUploadMb": MAX_UPLOAD_MB,
        "maxAudioDurationSec": MAX_AUDIO_DURATION_SEC,
    }


def _cleanup_runtime() -> None:
    """Best-effort cleanup for ephemeral hosting. Never lets cleanup break a request."""
    cutoff = time.time() - RUNTIME_TTL_HOURS * 3600
    try:
        for path in UPLOADS.glob("*"):
            if path.is_file() and path.stat().st_mtime < cutoff:
                path.unlink(missing_ok=True)
        for path in RESULTS.glob("*"):
            if path.is_dir() and path.stat().st_mtime < cutoff:
                shutil.rmtree(path, ignore_errors=True)
    except OSError:
        pass


def _probe_duration(path: Path) -> float | None:
    """Use ffprobe when available so overlong media is rejected before librosa loads it."""
    ffprobe = shutil.which("ffprobe")
    if not ffprobe:
        return None
    try:
        proc = subprocess.run(
            [ffprobe, "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", str(path)],
            check=True, capture_output=True, text=True, timeout=15,
        )
        return float(proc.stdout.strip())
    except (OSError, ValueError, subprocess.SubprocessError):
        return None


def _safe_extension(filename: str | None) -> str:
    ext = Path(filename or "audio.wav").suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(status_code=400, detail=f"지원하지 않는 파일 형식입니다: {ext or '(확장자 없음)'}")
    return ext


async def _save_upload(upload: UploadFile, target: Path) -> int:
    size = 0
    try:
        with target.open("wb") as out:
            while chunk := await upload.read(1024 * 1024):
                size += len(chunk)
                if size > MAX_UPLOAD_BYTES:
                    raise HTTPException(status_code=413, detail=f"파일이 너무 큽니다. 최대 {MAX_UPLOAD_MB}MB까지 업로드할 수 있습니다.")
                out.write(chunk)
    except Exception:
        target.unlink(missing_ok=True)
        raise
    finally:
        await upload.close()
    if size == 0:
        target.unlink(missing_ok=True)
        raise HTTPException(status_code=400, detail="빈 파일입니다.")
    return size


@app.post("/api/analyze")
async def analyze(
    file: UploadFile = File(...),
    difficulty: str = Form("hard"),
    seed: int = Form(42),
) -> dict:
    difficulty = difficulty.strip().lower()
    if difficulty not in DIFFICULTIES:
        raise HTTPException(status_code=400, detail="난이도는 easy/normal/hard/expert 중 하나여야 합니다.")
    if seed < -2_147_483_648 or seed > 2_147_483_647:
        raise HTTPException(status_code=400, detail="seed 범위가 너무 큽니다.")

    _cleanup_runtime()
    ext = _safe_extension(file.filename)
    analysis_id = uuid4().hex
    stored = UPLOADS / f"{analysis_id}{ext}"
    size = await _save_upload(file, stored)
    title = Path(file.filename or "Uploaded Song").stem

    duration = _probe_duration(stored)
    if duration is not None and duration > MAX_AUDIO_DURATION_SEC:
        stored.unlink(missing_ok=True)
        raise HTTPException(
            status_code=413,
            detail=f"미디어가 너무 깁니다. 최대 {MAX_AUDIO_DURATION_SEC / 60:.0f}분까지 분석할 수 있습니다.",
        )

    try:
        async with ANALYZE_SEMAPHORE:
            result = await run_in_threadpool(generate_chart, str(stored), difficulty, seed, title)
    except ChartGenError as exc:
        stored.unlink(missing_ok=True)
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception as exc:
        stored.unlink(missing_ok=True)
        raise HTTPException(status_code=500, detail=f"분석 중 예기치 않은 오류가 발생했습니다: {type(exc).__name__}") from exc

    result_dir = RESULTS / analysis_id
    result_dir.mkdir(parents=True, exist_ok=True)
    (result_dir / "chart.json").write_text(json.dumps(result.chart, ensure_ascii=False, indent=2), encoding="utf-8")
    (result_dir / "report.json").write_text(json.dumps(result.report, ensure_ascii=False, indent=2), encoding="utf-8")
    meta = {
        "id": analysis_id,
        "originalName": file.filename or stored.name,
        "storedName": stored.name,
        "size": size,
        "createdAt": datetime.now(timezone.utc).isoformat(),
    }
    (result_dir / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

    return {
        "id": analysis_id,
        "originalName": meta["originalName"],
        "mediaUrl": f"/api/media/{analysis_id}",
        "mediaKind": "video" if ext in {".mp4", ".webm"} else "audio",
        "chart": result.chart,
        "report": result.report,
    }


def _find_upload(analysis_id: str) -> Path:
    if not analysis_id.isalnum() or len(analysis_id) > 64:
        raise HTTPException(status_code=404, detail="파일을 찾을 수 없습니다.")
    matches = list(UPLOADS.glob(f"{analysis_id}.*"))
    if len(matches) != 1:
        raise HTTPException(status_code=404, detail="파일을 찾을 수 없습니다.")
    return matches[0]


@app.get("/api/media/{analysis_id}")
def media(analysis_id: str):
    path = _find_upload(analysis_id)
    media_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    return FileResponse(path, media_type=media_type, filename=path.name, headers={"Cache-Control": "no-store, private"})


@app.get("/api/result/{analysis_id}/{name}")
def result_file(analysis_id: str, name: str):
    if name not in {"chart.json", "report.json"}:
        raise HTTPException(status_code=404, detail="파일을 찾을 수 없습니다.")
    path = RESULTS / analysis_id / name
    if not path.is_file():
        raise HTTPException(status_code=404, detail="파일을 찾을 수 없습니다.")
    return FileResponse(path, media_type="application/json", filename=name, headers={"Cache-Control": "no-store, private"})


@app.post("/api/evaluations")
def save_evaluation(payload: EvaluationPayload) -> dict:
    required = {"timing", "musicality", "pattern", "density", "repetition", "fun"}
    if set(payload.ratings) != required:
        raise HTTPException(status_code=400, detail="평가 항목이 올바르지 않습니다.")
    if any(not isinstance(v, int) or v < 1 or v > 5 for v in payload.ratings.values()):
        raise HTTPException(status_code=400, detail="평점은 1~5 정수여야 합니다.")
    record = {
        **payload.model_dump(),
        "savedAt": datetime.now(timezone.utc).isoformat(),
    }
    EVALUATIONS.parent.mkdir(parents=True, exist_ok=True)
    with EVALUATIONS.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")
    return {"ok": True}


@app.delete("/api/session/{analysis_id}")
def delete_session(analysis_id: str) -> dict:
    try:
        upload = _find_upload(analysis_id)
        upload.unlink(missing_ok=True)
    except HTTPException:
        pass
    shutil.rmtree(RESULTS / analysis_id, ignore_errors=True)
    return {"ok": True}


DIST = ROOT / "dist"
if DIST.is_dir():
    assets = DIST / "assets"
    if assets.is_dir():
        app.mount("/assets", StaticFiles(directory=assets), name="assets")

    @app.get("/{full_path:path}")
    def spa(full_path: str):
        candidate = DIST / full_path
        if full_path and candidate.is_file() and DIST in candidate.resolve().parents:
            return FileResponse(candidate)
        return FileResponse(DIST / "index.html")
