import { useMemo, useState } from "react";
import type { AnalysisResponse } from "./types";

const DIFFICULTIES = ["easy", "normal", "hard", "expert"] as const;

interface Props {
  onComplete: (result: AnalysisResponse) => void;
}

function formatMb(bytes: number) {
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

export function UploadScreen({ onComplete }: Props) {
  const [file, setFile] = useState<File | null>(null);
  const [difficulty, setDifficulty] = useState<(typeof DIFFICULTIES)[number]>("hard");
  const [seed, setSeed] = useState(42);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const accept = useMemo(() => ".wav,.mp3,.flac,.ogg,.m4a,.aac,.webm,.mp4,audio/*,video/mp4", []);

  async function submit() {
    if (!file || busy) return;
    setBusy(true);
    setError(null);
    const form = new FormData();
    form.append("file", file);
    form.append("difficulty", difficulty);
    form.append("seed", String(seed));
    try {
      const res = await fetch("/api/analyze", { method: "POST", body: form });
      const payload = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(payload.detail || `분석 실패 (${res.status})`);
      onComplete(payload as AnalysisResponse);
    } catch (e) {
      setError(e instanceof Error ? e.message : "분석에 실패했습니다.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="lab-shell upload-shell">
      <header className="lab-header">
        <div className="eyebrow">AI RHYTHM LAB · v0.3 RC3</div>
        <h1>노래 하나 넣고, 바로 채보를 테스트해봐.</h1>
        <p>업로드한 음원을 현재 v0.3 Python 분석기로 처리한 뒤 기존 4키 엔진에서 바로 플레이합니다.</p>
      </header>

      <section className="upload-card">
        <label className={`file-drop ${file ? "has-file" : ""}`}>
          <input
            type="file"
            accept={accept}
            disabled={busy}
            onChange={(e) => setFile(e.target.files?.[0] ?? null)}
          />
          <span className="file-icon">♪</span>
          {file ? (
            <>
              <strong>{file.name}</strong>
              <span>{formatMb(file.size)}</span>
            </>
          ) : (
            <>
              <strong>노래 파일 선택</strong>
              <span>MP3 · WAV · FLAC · OGG · M4A · AAC · MP4 · WEBM / 최대 80MB</span>
            </>
          )}
        </label>

        <div className="option-block">
          <span className="option-label">난이도</span>
          <div className="difficulty-grid">
            {DIFFICULTIES.map((value) => (
              <button
                type="button"
                key={value}
                className={difficulty === value ? "selected" : ""}
                onClick={() => setDifficulty(value)}
                disabled={busy}
              >
                {value[0].toUpperCase() + value.slice(1)}
              </button>
            ))}
          </div>
        </div>

        <div className="seed-row">
          <label>
            <span className="option-label">Pattern seed</span>
            <input type="number" value={seed} onChange={(e) => setSeed(Number(e.target.value) || 0)} disabled={busy} />
          </label>
          <p>같은 곡 + 같은 seed면 같은 레인 패턴이 생성됩니다.</p>
        </div>

        {error && <div className="error-box">{error}</div>}

        <button className="primary-action" disabled={!file || busy} onClick={submit}>
          {busy ? "음악 분석 · 채보 생성 중…" : "AI 채보 생성"}
        </button>

        {busy && (
          <div className="analysis-progress" aria-live="polite">
            <div className="progress-bar"><span /></div>
            <div className="progress-steps">
              <span>Audio Analysis</span><span>Beat Grid</span><span>Musical Events</span><span>Playability</span>
            </div>
            <small>실제 곡은 길이와 기기에 따라 분석 시간이 달라질 수 있습니다.</small>
          </div>
        )}
      </section>
    </main>
  );
}
