import { useEffect, useRef } from "react";
import type { NoteRuntime } from "../types/chart";
import { computeNoteY, computeHoldTailLengthPx } from "../engine/renderer";

interface Props {
  notes: NoteRuntime[];
  currentTimeSec: number;
  width: number;
  height: number;
  judgeLineY: number;
  laneCount: number;
}

const LANE_COLORS = ["#7f77dd", "#1d9e75", "#d85a30", "#d4537e"];

/**
 * Canvas 2D로 노트를 그린다.
 * 매 프레임 activeNotes(현재 시각 근방의 노트)만 순회하도록,
 * 부모(GameScreen)에서 이미 activeWindow로 잘라 넘긴 notes를 받는다고 가정한다.
 */
export function NoteFieldCanvas({ notes, currentTimeSec, width, height, judgeLineY, laneCount }: Props) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    ctx.clearRect(0, 0, width, height);

    const laneWidth = width / laneCount;

    // 레인 구분선
    ctx.strokeStyle = "rgba(255,255,255,0.15)";
    for (let i = 1; i < laneCount; i++) {
      ctx.beginPath();
      ctx.moveTo(i * laneWidth, 0);
      ctx.lineTo(i * laneWidth, height);
      ctx.stroke();
    }

    // 판정선
    ctx.strokeStyle = "rgba(255,255,255,0.6)";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(0, judgeLineY);
    ctx.lineTo(width, judgeLineY);
    ctx.stroke();
    ctx.lineWidth = 1;

    for (const n of notes) {
      if (n.status !== "pending" && n.status !== "holding") continue;
      const x = n.note.lane * laneWidth + laneWidth * 0.1;
      const noteWidth = laneWidth * 0.8;
      const y = computeNoteY(n.note.time, currentTimeSec, judgeLineY);

      ctx.fillStyle = LANE_COLORS[n.note.lane % LANE_COLORS.length];

      if (n.note.type === "hold") {
        // 막대는 [노트 시작 시각 ~ 노트 종료 시각] 구간을 나타낸다.
        // 헤드(끝나는 지점, 화면상 아래쪽)는 y, 꼬리(시작 지점, 화면상 위쪽)는 y - tailLen.
        const tailLen = computeHoldTailLengthPx(n.note.duration, judgeLineY);
        const bottom = Math.min(y, judgeLineY); // 판정선을 넘어가지 않게 clip
        const top = y - tailLen;
        ctx.globalAlpha = n.status === "holding" ? 0.9 : 0.7;
        ctx.fillRect(x, top, noteWidth, Math.max(bottom - top, 8));
        ctx.globalAlpha = 1;
      } else if (n.note.type === "flick") {
        ctx.beginPath();
        ctx.moveTo(x + noteWidth / 2, y - 14);
        ctx.lineTo(x + noteWidth, y);
        ctx.lineTo(x + noteWidth / 2, y + 14);
        ctx.lineTo(x, y);
        ctx.closePath();
        ctx.fill();
      } else {
        ctx.fillRect(x, y - 9, noteWidth, 18);
      }
    }

  }, [notes, currentTimeSec, width, height, judgeLineY, laneCount]);

  return <canvas ref={canvasRef} width={width} height={height} style={{ display: "block", width: "100%", height: "100%" }} />;
}
