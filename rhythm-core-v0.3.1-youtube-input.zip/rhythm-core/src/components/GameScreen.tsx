import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import type { Chart, Lane, NoteRuntime } from "../types/chart";
import {
  attemptFlick,
  attemptHoldRelease,
  attemptHoldStart,
  attemptTap,
  createInitialGameState,
  restartGame,
  tick,
  type GameOptions,
  type GameState,
} from "../engine/gameState";
import { computeResult } from "../engine/resultCalculation";
import { useInputManager } from "../engine/inputManager";
import { useGameLoop } from "../hooks/useGameLoop";
import { getCurrentTimeSec, pauseVideo, playVideo, restartVideo } from "../engine/videoSync";
import { ACTIVE_WINDOW_SEC, LANE_KEYS, GAUGE_CONFIG } from "../constants/config";
import { NoteFieldCanvas } from "./NoteFieldCanvas";
import { PauseOverlay } from "./PauseOverlay";
import { ResultScreen } from "./ResultScreen";
import { YouTubeBackdrop, type YouTubeBackdropHandle } from "./YouTubeBackdrop";

interface Props {
  chart: Chart;
  mediaUrl: string;
  mediaKind?: "audio" | "video";
  mediaMuted?: boolean;
  requireStartGesture?: boolean;
  resultExtra?: ReactNode;
  youtubeVideoId?: string;
}

interface MvOptions {
  on: boolean;
  brightness: number;
  overlayOpacity: number;
  blurPx: number;
}

const CANVAS_WIDTH = 640;
const CANVAS_HEIGHT = 480;
const JUDGE_LINE_Y = CANVAS_HEIGHT - 80;
const LANE_COUNT = 4;

function isNoteActive(note: NoteRuntime, currentTimeSec: number): boolean {
  if (note.status !== "pending" && note.status !== "holding") return false;
  const endTime = note.note.type === "hold" ? note.note.time + note.note.duration : note.note.time;
  return note.note.time - currentTimeSec <= ACTIVE_WINDOW_SEC && endTime >= currentTimeSec - 0.5;
}

export function GameScreen({
  chart,
  mediaUrl,
  mediaKind = "video",
  mediaMuted = true,
  requireStartGesture = false,
  resultExtra,
  youtubeVideoId,
}: Props) {
  const [options] = useState<GameOptions>({ failEnabled: false });
  const [state, setState] = useState<GameState>(() => createInitialGameState(chart, options));
  const [paused, setPaused] = useState(false);
  const [currentTimeSec, setCurrentTimeSec] = useState(0);
  const [gameStarted, setGameStarted] = useState(!requireStartGesture);
  const [mv, setMv] = useState<MvOptions>({ on: true, brightness: 0.4, overlayOpacity: 0.5, blurPx: 0 });

  const mediaRef = useRef<HTMLMediaElement | null>(null);
  const youtubeRef = useRef<YouTubeBackdropHandle | null>(null);
  const stateRef = useRef(state);
  const pausedRef = useRef(paused);
  const touchStarts = useRef(new Map<number, { y: number; flicked: boolean }>());

  useEffect(() => { stateRef.current = state; }, [state]);
  useEffect(() => { pausedRef.current = paused; }, [paused]);

  const started = useRef(false);
  useEffect(() => {
    if (!requireStartGesture && !started.current) {
      started.current = true;
      playVideo(mediaRef.current);
      youtubeRef.current?.playAt(getCurrentTimeSec(mediaRef.current));
    }
  }, [requireStartGesture]);

  const loopActive = gameStarted && !state.finished;

  useGameLoop(() => {
    if (pausedRef.current) return;
    const media = mediaRef.current;
    const t = getCurrentTimeSec(media);
    setCurrentTimeSec(t);
    const ended = !!media && media.ended;
    setState((s) => tick(s, ended ? Number.POSITIVE_INFINITY : t));
  }, loopActive);

  const handleStart = useCallback(() => {
    setGameStarted(true);
    playVideo(mediaRef.current);
    youtubeRef.current?.playAt(getCurrentTimeSec(mediaRef.current));
  }, []);

  const handlePauseToggle = useCallback(() => {
    if (!gameStarted) return;
    setPaused((p) => {
      const next = !p;
      if (next) {
        pauseVideo(mediaRef.current);
        youtubeRef.current?.pause();
      } else {
        playVideo(mediaRef.current);
        youtubeRef.current?.playAt(getCurrentTimeSec(mediaRef.current));
      }
      return next;
    });
  }, [gameStarted]);

  const handleLaneKeyDown = useCallback((lane: Lane) => {
    if (!gameStarted || pausedRef.current || stateRef.current.failed || stateRef.current.finished) return;
    const t = getCurrentTimeSec(mediaRef.current);
    setState((s) => attemptHoldStart(attemptTap(s, lane, t), lane, t));
  }, [gameStarted]);

  const handleLaneKeyUp = useCallback((lane: Lane) => {
    if (!gameStarted || pausedRef.current || stateRef.current.failed || stateRef.current.finished) return;
    const t = getCurrentTimeSec(mediaRef.current);
    setState((s) => attemptHoldRelease(s, lane, t));
  }, [gameStarted]);

  const handleFlick = useCallback((lane: Lane) => {
    if (!gameStarted || pausedRef.current || stateRef.current.failed || stateRef.current.finished) return;
    const t = getCurrentTimeSec(mediaRef.current);
    setState((s) => attemptFlick(s, lane, t));
  }, [gameStarted]);

  const inputCallbacks = useMemo(() => ({
    onLaneKeyDown: handleLaneKeyDown,
    onLaneKeyUp: handleLaneKeyUp,
    onFlick: handleFlick,
    onPauseToggle: handlePauseToggle,
  }), [handleLaneKeyDown, handleLaneKeyUp, handleFlick, handlePauseToggle]);

  useInputManager(inputCallbacks, gameStarted);

  const handleRestart = useCallback(() => {
    setState((s) => restartGame(s));
    setPaused(false);
    setCurrentTimeSec(0);
    restartVideo(mediaRef.current);
    youtubeRef.current?.restart();
    if (requireStartGesture) setGameStarted(false);
    else {
      playVideo(mediaRef.current);
      youtubeRef.current?.playAt(0);
    }
  }, [requireStartGesture]);

  useEffect(() => {
    if (!youtubeVideoId || !gameStarted || paused || state.finished) return;
    const timer = window.setInterval(() => {
      youtubeRef.current?.syncTo(getCurrentTimeSec(mediaRef.current));
    }, 1200);
    return () => window.clearInterval(timer);
  }, [youtubeVideoId, gameStarted, paused, state.finished]);

  useEffect(() => {
    if (state.finished) youtubeRef.current?.pause();
  }, [state.finished]);

  const activeNotes = useMemo(
    () => state.notes.filter((n) => isNoteActive(n, currentTimeSec)),
    [state.notes, currentTimeSec]
  );
  const result = useMemo(() => computeResult(state), [state]);

  useEffect(() => {
    (window as unknown as { __RHYTHM_DEBUG__?: unknown }).__RHYTHM_DEBUG__ = { state, currentTimeSec, paused, gameStarted };
  }, [state, currentTimeSec, paused, gameStarted]);

  const videoFilter = `brightness(${mv.brightness}) blur(${mv.blurPx}px)`;
  const mediaNode = mediaKind === "audio" ? (
    <audio ref={(node) => { mediaRef.current = node; }} src={mediaUrl} preload="auto" />
  ) : (
    <video
      ref={(node) => { mediaRef.current = node; }}
      src={mediaUrl}
      muted={mediaMuted}
      playsInline
      preload="auto"
      style={mv.on ? { position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", filter: videoFilter } : { display: "none" }}
    />
  );

  return (
    <div className="game-screen">
      <div className="hud-top">
        <div><strong>{chart.title}</strong> <span className="muted">/ {chart.artist}</span></div>
        <div>{chart.difficulty} Lv.{chart.level}</div>
        <div>Gauge {Math.round(state.gauge)}/{GAUGE_CONFIG.MAX}</div>
        <div>Acc {result.accuracyPercent.toFixed(1)}%</div>
        <button type="button" className="touch-pause" onClick={handlePauseToggle} disabled={!gameStarted || state.finished}>일시정지</button>
      </div>

      <div className={`stage ${mediaKind === "audio" ? "audio-stage" : ""}`}>
        {mediaNode}
        {youtubeVideoId && <YouTubeBackdrop ref={youtubeRef} videoId={youtubeVideoId} visible={mv.on} brightness={mv.brightness} blurPx={mv.blurPx} />}
        {(mediaKind === "video" || youtubeVideoId) && <div className="mv-overlay" style={{ position: "absolute", inset: 0, background: `rgba(0,0,0,${mv.overlayOpacity})` }} />}
        {mediaKind === "audio" && !youtubeVideoId && <div className="audio-backdrop"><span>AI CHART</span><b>{Math.round(chart.bpm)} BPM</b></div>}

        <div className="combo-display">
          {state.combo > 0 && <div className="combo-number">{state.combo}</div>}
          {state.lastJudgement && <div className={`judgement-text ${state.lastJudgement.toLowerCase()}`}>{state.lastJudgement}</div>}
        </div>

        <div style={{ position: "absolute", inset: 0 }}>
          <NoteFieldCanvas notes={activeNotes} currentTimeSec={currentTimeSec} width={CANVAS_WIDTH} height={CANVAS_HEIGHT} judgeLineY={JUDGE_LINE_Y} laneCount={LANE_COUNT} />
        </div>

        <div className="touch-lanes">
          {([0, 1, 2, 3] as Lane[]).map((lane) => (
            <button
              key={lane}
              type="button"
              className={`touch-lane lane-${lane}`}
              onPointerDown={(e) => {
                e.preventDefault(); e.currentTarget.setPointerCapture(e.pointerId);
                touchStarts.current.set(e.pointerId, { y: e.clientY, flicked: false });
                handleLaneKeyDown(lane);
              }}
              onPointerMove={(e) => {
                const touch = touchStarts.current.get(e.pointerId);
                if (touch && !touch.flicked && touch.y - e.clientY > 28) {
                  touch.flicked = true;
                  handleFlick(lane);
                }
              }}
              onPointerUp={(e) => {
                e.preventDefault(); touchStarts.current.delete(e.pointerId);
                handleLaneKeyUp(lane);
              }}
              onPointerCancel={(e) => { touchStarts.current.delete(e.pointerId); handleLaneKeyUp(lane); }}
            >
              {LANE_KEYS[lane].toUpperCase()}
            </button>
          ))}
        </div>

        {!gameStarted && (
          <div className="start-overlay">
            <div className="start-card">
              <span>준비됐으면</span>
              <button onClick={handleStart}>START</button>
              <small>키보드 D F J K · 터치: 누르기/홀드 · Flick: 위로 밀기</small>
            </div>
          </div>
        )}
        {paused && <PauseOverlay onResume={handlePauseToggle} onRestart={handleRestart} />}
      </div>

      {(mediaKind === "video" || youtubeVideoId) && (
        <div className="mv-options">
          <label><input type="checkbox" checked={mv.on} onChange={(e) => setMv((m) => ({ ...m, on: e.target.checked }))} /> MV</label>
          <label>밝기 <input type="range" min={0} max={1} step={0.05} value={mv.brightness} onChange={(e) => setMv((m) => ({ ...m, brightness: Number(e.target.value) }))} /></label>
          <label>오버레이 <input type="range" min={0} max={1} step={0.05} value={mv.overlayOpacity} onChange={(e) => setMv((m) => ({ ...m, overlayOpacity: Number(e.target.value) }))} /></label>
          <label>블러 <input type="range" min={0} max={10} step={1} value={mv.blurPx} onChange={(e) => setMv((m) => ({ ...m, blurPx: Number(e.target.value) }))} /></label>
        </div>
      )}

      {state.finished && <><ResultScreen result={result} onRestart={handleRestart} onReplay={handleRestart} />{resultExtra}</>}
    </div>
  );
}
