import type { GameResult } from "../engine/resultCalculation";

interface Props {
  result: GameResult;
  onRestart: () => void;
  onReplay: () => void;
}

export function ResultScreen({ result, onRestart, onReplay }: Props) {
  return (
    <div className="result-screen">
      <h2>결과</h2>
      <div className="result-score">{result.score}</div>
      <div className="result-grid">
        <div>
          <span className="label">Accuracy</span>
          <span className="value">{result.accuracyPercent.toFixed(2)}%</span>
        </div>
        <div>
          <span className="label">Max Combo</span>
          <span className="value">{result.maxCombo}</span>
        </div>
      </div>
      <div className="result-counts">
        <div className="perfect">Perfect {result.perfect}</div>
        <div className="great">Great {result.great}</div>
        <div className="good">Good {result.good}</div>
        <div className="miss">Miss {result.miss}</div>
      </div>
      <div className="result-buttons">
        <button onClick={onRestart}>Restart</button>
        <button onClick={onReplay}>다시 플레이</button>
      </div>
    </div>
  );
}
