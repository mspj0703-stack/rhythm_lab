import { useMemo, useState } from "react";
import type { AnalysisResponse } from "./types";

const DIFFICULTIES = ["easy", "normal", "hard", "expert"] as const;
type InputMode = "youtube" | "file";

interface Props { onComplete: (result: AnalysisResponse) => void; }
function formatMb(bytes: number) { return `${(bytes / 1024 / 1024).toFixed(1)} MB`; }

export function UploadScreen({ onComplete }: Props) {
  const [mode, setMode] = useState<InputMode>("youtube");
  const [url, setUrl] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [difficulty, setDifficulty] = useState<(typeof DIFFICULTIES)[number]>("hard");
  const [seed, setSeed] = useState(42);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const accept = useMemo(() => ".wav,.mp3,.flac,.ogg,.m4a,.aac,.webm,.mp4,audio/*,video/mp4", []);

  async function submit() {
    if (busy || (mode === "file" ? !file : !url.trim())) return;
    setBusy(true); setError(null);
    try {
      let res: Response;
      if (mode === "youtube") {
        res = await fetch("/api/analyze-youtube", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ url: url.trim(), difficulty, seed }),
        });
      } else {
        const form = new FormData();
        form.append("file", file!); form.append("difficulty", difficulty); form.append("seed", String(seed));
        res = await fetch("/api/analyze", { method: "POST", body: form });
      }
      const payload = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(payload.detail || `분석 실패 (${res.status})`);
      onComplete(payload as AnalysisResponse);
    } catch (e) { setError(e instanceof Error ? e.message : "분석에 실패했습니다."); }
    finally { setBusy(false); }
  }

  return (
    <main className="lab-shell upload-shell">
      <header className="lab-header">
        <div className="eyebrow">AI RHYTHM LAB · v0.3.1</div>
        <h1>링크 하나 넣고, 바로 채보를 테스트해봐.</h1>
        <p>YouTube 링크 또는 직접 업로드한 곡을 분석해 4키 채보를 자동 생성합니다.</p>
      </header>
      <section className="upload-card">
        <div className="input-tabs">
          <button className={mode === "youtube" ? "selected" : ""} onClick={() => setMode("youtube")} disabled={busy}>YouTube 링크</button>
          <button className={mode === "file" ? "selected" : ""} onClick={() => setMode("file")} disabled={busy}>파일 업로드</button>
        </div>

        {mode === "youtube" ? (
          <div className="youtube-input-block">
            <span className="youtube-icon">▶</span>
            <label htmlFor="youtube-url">YouTube 영상 링크</label>
            <input id="youtube-url" type="url" inputMode="url" placeholder="https://youtu.be/..." value={url}
              onChange={(e) => setUrl(e.target.value)} disabled={busy} autoCapitalize="none" autoCorrect="off" />
            <small>공개 영상 1개 · 최대 8분/80MB. 일부 영상은 YouTube 측 제한으로 가져오지 못할 수 있습니다.</small>
          </div>
        ) : (
          <label className={`file-drop ${file ? "has-file" : ""}`}>
            <input type="file" accept={accept} disabled={busy} onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
            <span className="file-icon">♪</span>
            {file ? <><strong>{file.name}</strong><span>{formatMb(file.size)}</span></> : <><strong>노래 파일 선택</strong><span>MP3 · WAV · FLAC · OGG · M4A · AAC · MP4 · WEBM / 최대 80MB</span></>}
          </label>
        )}

        <div className="option-block"><span className="option-label">난이도</span><div className="difficulty-grid">
          {DIFFICULTIES.map((value) => <button type="button" key={value} className={difficulty === value ? "selected" : ""} onClick={() => setDifficulty(value)} disabled={busy}>{value[0].toUpperCase() + value.slice(1)}</button>)}
        </div></div>
        <div className="seed-row"><label><span className="option-label">Pattern seed</span><input type="number" value={seed} onChange={(e) => setSeed(Number(e.target.value) || 0)} disabled={busy} /></label><p>같은 곡 + 같은 seed면 같은 레인 패턴이 생성됩니다.</p></div>
        {error && <div className="error-box">{error}</div>}
        <button className="primary-action" disabled={busy || (mode === "file" ? !file : !url.trim())} onClick={submit}>{busy ? (mode === "youtube" ? "YouTube 가져오기 · 분석 중…" : "음악 분석 · 채보 생성 중…") : "AI 채보 생성"}</button>
        {busy && <div className="analysis-progress" aria-live="polite"><div className="progress-bar"><span /></div><div className="progress-steps"><span>{mode === "youtube" ? "YouTube Fetch" : "Audio Analysis"}</span><span>Beat Grid</span><span>Musical Events</span><span>Playability</span></div><small>영상 길이와 서버 상태에 따라 잠시 걸릴 수 있습니다.</small></div>}
      </section>
    </main>
  );
}
