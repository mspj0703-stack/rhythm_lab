import { useEffect, useMemo, useState } from "react";
import { loadChartFromUrl, parseChart } from "./engine/chartLoader";
import type { Chart } from "./types/chart";
import { GameScreen } from "./components/GameScreen";
import { UploadScreen } from "./web/UploadScreen";
import { AnalysisSummary } from "./web/AnalysisSummary";
import { EvaluationPanel } from "./web/EvaluationPanel";
import type { AnalysisResponse } from "./web/types";
import testChartRaw from "./charts/testChart.json?raw";
import "./App.css";

const DEFAULT_VIDEO = "/test-video.mp4";

interface Source {
  chartUrl: string | null;
  videoUrl: string;
}

function readSource(): Source {
  const params = new URLSearchParams(window.location.search);
  return { chartUrl: params.get("chart"), videoUrl: params.get("video") ?? DEFAULT_VIDEO };
}

function loadBuiltinChart(): { chart: Chart | null; error: string | null } {
  try {
    return { chart: parseChart(testChartRaw), error: null };
  } catch (e) {
    return { chart: null, error: (e as Error).message };
  }
}

function LegacyGame() {
  const [source] = useState(readSource);
  const [loaded, setLoaded] = useState<{ chart: Chart | null; error: string | null }>(() =>
    source.chartUrl ? { chart: null, error: null } : loadBuiltinChart()
  );

  useEffect(() => {
    if (!source.chartUrl) return;
    let cancelled = false;
    loadChartFromUrl(source.chartUrl)
      .then((chart) => !cancelled && setLoaded({ chart, error: null }))
      .catch((e: Error) => !cancelled && setLoaded({ chart: null, error: e.message }));
    return () => { cancelled = true; };
  }, [source.chartUrl]);

  if (loaded.error) return <div className="app-error">채보 로드 실패: {loaded.error}</div>;
  if (!loaded.chart) return <div className="app-loading">불러오는 중...</div>;
  return <div className="app-root"><GameScreen chart={loaded.chart} mediaUrl={source.videoUrl} mediaKind="video" mediaMuted /></div>;
}

function App() {
  const params = useMemo(() => new URLSearchParams(window.location.search), []);
  const legacyMode = params.has("chart") || params.has("video") || params.has("legacy");
  const [analysis, setAnalysis] = useState<AnalysisResponse | null>(null);
  const [playing, setPlaying] = useState(false);

  async function resetAnalysis() {
    const current = analysis;
    setPlaying(false);
    setAnalysis(null);
    if (current) {
      try { await fetch(`/api/session/${current.id}`, { method: "DELETE" }); } catch { /* TTL cleanup is the fallback */ }
    }
  }

  if (legacyMode) return <LegacyGame />;
  if (!analysis) return <UploadScreen onComplete={setAnalysis} />;
  if (!playing) return <AnalysisSummary data={analysis} onPlay={() => setPlaying(true)} onReset={resetAnalysis} />;

  const parsed = parseChart(JSON.stringify(analysis.chart));
  return (
    <main className="play-page">
      <div className="play-toolbar">
        <button onClick={() => setPlaying(false)}>← 분석 결과</button>
        <span>{analysis.originalName}</span>
      </div>
      <GameScreen
        chart={parsed}
        mediaUrl={analysis.mediaUrl}
        mediaKind={analysis.mediaKind}
        mediaMuted={false}
        requireStartGesture
        resultExtra={<EvaluationPanel analysisId={analysis.id} songName={analysis.chart.title} />}
      />
    </main>
  );
}

export default App;
