import type { Chart, JudgementLabel, Lane, NoteRuntime } from "../types/chart";
import { createNoteRuntimes } from "./chartLoader";
import {
  classifyByTimingDiff,
  findCompletedHoldNotes,
  findExpiredPendingNotes,
  findNearestJudgeableNote,
  judgeHoldRelease,
} from "./judgementEngine";
import { calculateNoteScore } from "./scoring";
import { applyJudgementToGauge, isFailed } from "./gauge";
import { ACCURACY_WEIGHT, GAUGE_CONFIG } from "../constants/config";

export interface GameOptions {
  /** 개발/테스트 편의를 위해 게이지 실패를 끌 수 있는 옵션 */
  failEnabled: boolean;
}

export interface GameState {
  chart: Chart;
  notes: NoteRuntime[];
  score: number;
  combo: number;
  maxCombo: number;
  gauge: number;
  failed: boolean;
  finished: boolean;
  options: GameOptions;
  judgementCounts: Record<JudgementLabel, number>;
  totalJudged: number;
  accuracyWeightSum: number;
  /** 마지막으로 발생한 판정 (UI에서 텍스트 연출용, 다음 판정 전까지 유지) */
  lastJudgement: JudgementLabel | null;
}

export function createInitialGameState(chart: Chart, options: GameOptions): GameState {
  return {
    chart,
    notes: createNoteRuntimes(chart),
    score: 0,
    combo: 0,
    maxCombo: 0,
    gauge: GAUGE_CONFIG.INITIAL,
    failed: false,
    finished: false,
    options,
    judgementCounts: { Perfect: 0, Great: 0, Good: 0, Miss: 0 },
    totalJudged: 0,
    accuracyWeightSum: 0,
    lastJudgement: null,
  };
}

/** 현재 콤보/점수/게이지/카운트에 판정 하나를 반영한 "새 상태 조각"을 계산한다. */
function applyJudgement(
  state: GameState,
  judgement: JudgementLabel
): Pick<
  GameState,
  "score" | "combo" | "maxCombo" | "gauge" | "failed" | "judgementCounts" | "totalJudged" | "accuracyWeightSum" | "lastJudgement"
> {
  const comboBefore = judgement === "Miss" ? state.combo : state.combo;
  const scoreDelta = calculateNoteScore(judgement, comboBefore);
  const nextCombo = judgement === "Miss" ? 0 : state.combo + 1;
  const nextGauge = applyJudgementToGauge(state.gauge, judgement);

  return {
    score: state.score + scoreDelta,
    combo: nextCombo,
    maxCombo: Math.max(state.maxCombo, nextCombo),
    gauge: nextGauge,
    failed: state.failed || isFailed(nextGauge, state.options.failEnabled),
    judgementCounts: {
      ...state.judgementCounts,
      [judgement]: state.judgementCounts[judgement] + 1,
    },
    totalJudged: state.totalJudged + 1,
    accuracyWeightSum: state.accuracyWeightSum + ACCURACY_WEIGHT[judgement],
    lastJudgement: judgement,
  };
}

function replaceNote(notes: NoteRuntime[], updated: NoteRuntime): NoteRuntime[] {
  const copy = notes.slice();
  copy[updated.index] = updated;
  return copy;
}

/** Tap 노트 판정 시도. 대상이 없으면 상태 변화 없이 그대로 반환한다 (허공 입력은 무페널티). */
export function attemptTap(state: GameState, lane: Lane, currentTimeSec: number): GameState {
  if (state.failed || state.finished) return state;

  const candidates = state.notes.filter((n) => n.note.type === "tap");
  const target = findNearestJudgeableNote(candidates, lane, currentTimeSec, ["pending"]);
  if (!target) return state;

  const diffMs = (currentTimeSec - target.note.time) * 1000;
  const judgement = classifyByTimingDiff(diffMs) ?? "Good";

  const updatedNote: NoteRuntime = { ...target, status: "hit", judgement };
  const patch = applyJudgement(state, judgement);

  return { ...state, ...patch, notes: replaceNote(state.notes, updatedNote) };
}

/** Hold 노트 시작 시도. */
export function attemptHoldStart(state: GameState, lane: Lane, currentTimeSec: number): GameState {
  if (state.failed || state.finished) return state;

  const candidates = state.notes.filter((n) => n.note.type === "hold");
  const target = findNearestJudgeableNote(candidates, lane, currentTimeSec, ["pending"]);
  if (!target) return state;

  const diffMs = (currentTimeSec - target.note.time) * 1000;
  const startJudgement = classifyByTimingDiff(diffMs) ?? "Good";

  // 시작 판정은 콤보/점수/게이지에 즉시 반영하지 않고, 종료 시점에 한 번에 반영한다.
  // (시작 성공 여부만 상태로 표시)
  const updatedNote: NoteRuntime = {
    ...target,
    status: "holding",
    judgement: startJudgement,
    holdStartedAt: currentTimeSec,
  };

  return { ...state, notes: replaceNote(state.notes, updatedNote) };
}

/** Hold 노트 유지 중 키를 뗐을 때 호출. */
export function attemptHoldRelease(state: GameState, lane: Lane, currentTimeSec: number): GameState {
  if (state.failed || state.finished) return state;

  const holding = state.notes.find(
    (n) => n.note.lane === lane && n.status === "holding" && n.note.type === "hold"
  );
  if (!holding) return state;

  const outcome = judgeHoldRelease(holding, currentTimeSec);

  if (outcome === "completed") {
    const judgement = holding.judgement ?? "Good";
    const updatedNote: NoteRuntime = { ...holding, status: "hit" };
    const patch = applyJudgement(state, judgement);
    return { ...state, ...patch, notes: replaceNote(state.notes, updatedNote) };
  }

  // 조기 이탈 -> Miss 처리
  const updatedNote: NoteRuntime = { ...holding, status: "hold_broken", judgement: "Miss" };
  const patch = applyJudgement(state, "Miss");
  return { ...state, ...patch, notes: replaceNote(state.notes, updatedNote) };
}

/** Flick 판정 시도 (레인 키 + Space 조합이 완성된 시점에 호출). */
export function attemptFlick(state: GameState, lane: Lane, currentTimeSec: number): GameState {
  if (state.failed || state.finished) return state;

  const candidates = state.notes.filter((n) => n.note.type === "flick");
  const target = findNearestJudgeableNote(candidates, lane, currentTimeSec, ["pending"]);
  if (!target) return state;

  const diffMs = (currentTimeSec - target.note.time) * 1000;
  const judgement = classifyByTimingDiff(diffMs) ?? "Good";

  const updatedNote: NoteRuntime = { ...target, status: "hit", judgement };
  const patch = applyJudgement(state, judgement);

  return { ...state, ...patch, notes: replaceNote(state.notes, updatedNote) };
}

/**
 * 매 프레임 호출: 판정 기회를 놓친 pending 노트를 Miss 처리하고,
 * 유지 시간을 다 채운 holding 노트를 정상 완료 처리한다.
 * 마지막 노트까지 지나갔으면 finished=true로 표시한다.
 */
export function tick(state: GameState, currentTimeSec: number): GameState {
  if (state.finished) return state;

  let next = state;

  const expired = findExpiredPendingNotes(next.notes, currentTimeSec);
  for (const n of expired) {
    const updatedNote: NoteRuntime = { ...n, status: "missed", judgement: "Miss" };
    const patch = applyJudgement(next, "Miss");
    next = { ...next, ...patch, notes: replaceNote(next.notes, updatedNote) };
  }

  const completedHolds = findCompletedHoldNotes(next.notes, currentTimeSec);
  for (const n of completedHolds) {
    const judgement = n.judgement ?? "Good";
    const updatedNote: NoteRuntime = { ...n, status: "hit" };
    const patch = applyJudgement(next, judgement);
    next = { ...next, ...patch, notes: replaceNote(next.notes, updatedNote) };
  }

  const allResolved = next.notes.every((n) => n.status === "hit" || n.status === "missed" || n.status === "hold_broken");
  const lastNoteEndTime = next.chart.notes.reduce((max, n) => {
    const endTime = n.type === "hold" ? n.time + n.duration : n.time;
    return Math.max(max, endTime);
  }, 0);

  if (allResolved && currentTimeSec > lastNoteEndTime + 0.5) {
    next = { ...next, finished: true };
  }

  return next;
}

export function restartGame(state: GameState): GameState {
  return createInitialGameState(state.chart, state.options);
}

export function calculateAccuracyPercent(state: GameState): number {
  if (state.totalJudged === 0) return 100;
  return (state.accuracyWeightSum / state.totalJudged) * 100;
}
