import type { GameState } from "./gameState";
import { calculateAccuracyPercent } from "./gameState";

export interface GameResult {
  score: number;
  accuracyPercent: number;
  maxCombo: number;
  perfect: number;
  great: number;
  good: number;
  miss: number;
}

export function computeResult(state: GameState): GameResult {
  return {
    score: Math.round(state.score),
    accuracyPercent: Math.round(calculateAccuracyPercent(state) * 100) / 100,
    maxCombo: state.maxCombo,
    perfect: state.judgementCounts.Perfect,
    great: state.judgementCounts.Great,
    good: state.judgementCounts.Good,
    miss: state.judgementCounts.Miss,
  };
}
