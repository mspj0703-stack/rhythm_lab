"""
1단계: Audio Analysis.

오디오 파일 -> AudioFeatures. 이 단계는 게임 규칙을 모르며 음악 신호 특징만 뽑는다.
v0.3부터 실제 곡의 half/double/3:2 tempo 오류를 추적할 수 있도록 tempo 후보와
로컬 대비 기반 분석을 위한 원시 특징을 함께 보존한다.
"""
from __future__ import annotations

import math
import os
from dataclasses import dataclass, field

import librosa
import numpy as np

from . import config as C
from .errors import AudioLoadError


@dataclass
class TempoCandidate:
    bpm: float
    grid_fit: float
    confidence: float
    ratio_from_initial: float
    beat_accent: float = 0.0
    selected: bool = False

    def to_dict(self) -> dict:
        return {
            "bpm": round(float(self.bpm), 2),
            "gridFit": round(float(self.grid_fit), 4) if math.isfinite(self.grid_fit) else None,
            "confidence": round(float(self.confidence), 4),
            "ratioFromInitial": round(float(self.ratio_from_initial), 4),
            "beatAccent": round(float(self.beat_accent), 4),
            "selected": bool(self.selected),
        }


@dataclass
class AudioFeatures:
    sr: int
    hop_length: int
    duration: float
    bpm: float
    beat_times: np.ndarray
    onset_frames: np.ndarray
    onset_times: np.ndarray
    onset_env: np.ndarray
    rms: np.ndarray
    rms_max_raw: float
    spectral_centroid: np.ndarray
    band_onset: dict[str, np.ndarray] = field(default_factory=dict)
    band_energy: dict[str, np.ndarray] = field(default_factory=dict)
    tempo_candidates: list[TempoCandidate] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def is_silent(self) -> bool:
        return self.rms_max_raw < C.SILENCE_RMS_THRESHOLD

    @property
    def bpm_confidence(self) -> float:
        selected = next((x for x in self.tempo_candidates if x.selected), None)
        return float(selected.confidence) if selected else (1.0 if self.bpm > 0 else 0.0)

    def frame_to_time(self, frame: int) -> float:
        return float(frame * self.hop_length / self.sr)

    def to_summary(self) -> dict:
        return {
            "sr": self.sr,
            "hopLength": self.hop_length,
            "duration": round(self.duration, 3),
            "bpm": round(self.bpm, 2),
            "bpmConfidence": round(self.bpm_confidence, 4),
            "tempoCandidates": [x.to_dict() for x in self.tempo_candidates],
            "beatTimes": [round(float(t), 4) for t in self.beat_times],
            "onsetTimes": [round(float(t), 4) for t in self.onset_times],
            "onsetStrengths": [round(float(self.onset_env[f]), 4) for f in self.onset_frames],
            "meanRms": round(float(self.rms.mean()) if self.rms.size else 0.0, 4),
            "meanSpectralCentroid": round(float(self.spectral_centroid.mean()) if self.spectral_centroid.size else 0.0, 1),
            "bandEnergyMean": {k: round(float(v.mean()) if v.size else 0.0, 4) for k, v in self.band_energy.items()},
            "isSilent": self.is_silent,
            "warnings": list(self.warnings),
        }


def load_audio(path: str) -> tuple[np.ndarray, int]:
    if not os.path.isfile(path):
        raise AudioLoadError(f"오디오 파일을 찾을 수 없습니다: {path}")
    if os.path.getsize(path) == 0:
        raise AudioLoadError(f"빈 파일입니다: {path}")
    try:
        y, sr = librosa.load(path, sr=C.SAMPLE_RATE, mono=True)
    except Exception as e:
        raise AudioLoadError(f"오디오를 디코딩할 수 없습니다: {path} ({type(e).__name__}: {e})") from e
    if y.ndim != 1:
        raise AudioLoadError("모노 변환에 실패했습니다.")
    if not np.all(np.isfinite(y)):
        raise AudioLoadError("오디오에 NaN/Inf 샘플이 포함되어 있습니다.")
    return y, int(sr)


def _normalize(a: np.ndarray) -> np.ndarray:
    if a.size == 0:
        return a
    m = float(np.max(a))
    return a / m if m > 0 else np.zeros_like(a)


def _empty_features(sr: int, duration: float, rms_max_raw: float, warning: str) -> AudioFeatures:
    empty = np.array([], dtype=float)
    return AudioFeatures(
        sr=sr,
        hop_length=C.HOP_LENGTH,
        duration=duration,
        bpm=0.0,
        beat_times=empty,
        onset_frames=np.array([], dtype=int),
        onset_times=empty,
        onset_env=empty,
        rms=empty,
        rms_max_raw=rms_max_raw,
        spectral_centroid=empty,
        band_onset={k: empty for k in C.FREQUENCY_BANDS},
        band_energy={k: empty for k in C.FREQUENCY_BANDS},
        tempo_candidates=[],
        warnings=[warning],
    )


def grid_fit_score(beat_times: np.ndarray, duration: float, onset_times: np.ndarray, weights: np.ndarray) -> float:
    """onset들이 1/8 grid에 얼마나 잘 맞는지. 0에 가까울수록 좋다."""
    from .beatgrid import BeatGrid

    grid = BeatGrid.from_beats(beat_times, duration, subdivisions=2)
    if grid.is_empty or onset_times.size == 0:
        return float("inf")
    eighth = grid.sixteenth_interval
    offs = np.array([abs(grid.quantize(float(t), threshold_sec=1e9).offset_sec) for t in onset_times]) / eighth
    w = weights if weights.size == onset_times.size and weights.sum() > 0 else np.ones_like(offs)
    return float(np.sum(offs * w) / np.sum(w))


def _beat_accent_score(beat_times: np.ndarray, onset_times: np.ndarray, weights: np.ndarray) -> float:
    """Strong-event mass that lands on candidate quarter-note beats (0..1)."""
    if beat_times.size < 2 or onset_times.size == 0:
        return 0.0
    interval = float(np.median(np.diff(beat_times)))
    tol = min(C.TEMPO_BEAT_ACCENT_TOLERANCE_SEC, interval * C.TEMPO_BEAT_ACCENT_TOLERANCE_FRACTION)
    idx = np.clip(np.searchsorted(beat_times, onset_times), 1, beat_times.size - 1)
    dist = np.minimum(np.abs(onset_times - beat_times[idx - 1]), np.abs(onset_times - beat_times[idx]))
    w = weights if weights.size == onset_times.size and weights.sum() > 0 else np.ones_like(onset_times)
    return float(np.sum(w[dist <= tol]) / np.sum(w))


def _tempo_evaluations(
    onset_env_raw: np.ndarray,
    sr: int,
    hop: int,
    duration: float,
    initial_bpm: float,
    initial_beats: np.ndarray,
    onset_times: np.ndarray,
    onset_strengths: np.ndarray,
) -> list[tuple[float, float, np.ndarray, float, float]]:
    """(grid_fit, bpm, beat_times, ratio_from_initial, beat_accent) 후보 목록."""
    if initial_bpm <= 0:
        return []

    requested: list[tuple[float, float]] = [(initial_bpm, 1.0)]
    requested.extend((initial_bpm * r, r) for r in C.TEMPO_REFINE_RATIOS)
    seen: set[int] = set()
    out: list[tuple[float, float, np.ndarray, float, float]] = []

    for cand, ratio in requested:
        if not C.TEMPO_MIN_BPM <= cand <= C.TEMPO_MAX_BPM:
            continue
        key = int(round(cand * 10))
        if key in seen:
            continue
        seen.add(key)
        if abs(ratio - 1.0) < 1e-9:
            bpm2 = float(initial_bpm)
            bt2 = np.asarray(initial_beats, dtype=float)
        else:
            t2, bf2 = librosa.beat.beat_track(onset_envelope=onset_env_raw, sr=sr, hop_length=hop, bpm=cand)
            bpm2 = float(np.atleast_1d(t2)[0])
            bt2 = librosa.frames_to_time(bf2, sr=sr, hop_length=hop)
        score = grid_fit_score(bt2, duration, onset_times, onset_strengths)
        accent = _beat_accent_score(np.asarray(bt2, dtype=float), onset_times, onset_strengths)
        out.append((score, bpm2, np.asarray(bt2, dtype=float), ratio, accent))
    return out

def _candidates_for_report(
    evaluations: list[tuple[float, float, np.ndarray, float, float]], selected_bpm: float
) -> list[TempoCandidate]:
    finite = [x for x in evaluations if math.isfinite(x[0])]
    if not finite:
        return []
    raw = [math.exp(-C.TEMPO_CONFIDENCE_SCALE * max(0.0, x[0])) for x in finite]
    total = sum(raw) or 1.0
    ranked: list[TempoCandidate] = []
    for ev, weight in zip(finite, raw, strict=True):
        score, bpm, _, ratio, beat_accent = ev
        ranked.append(
            TempoCandidate(
                bpm=bpm,
                grid_fit=score,
                confidence=weight / total,
                ratio_from_initial=ratio,
                beat_accent=beat_accent,
                selected=abs(bpm - selected_bpm) < 0.75,
            )
        )
    ranked.sort(key=lambda x: (not x.selected, -x.confidence, x.grid_fit))
    return ranked[: C.TEMPO_CANDIDATE_LIMIT]

def refine_tempo(
    onset_env_raw: np.ndarray,
    sr: int,
    hop: int,
    duration: float,
    bpm: float,
    beat_times: np.ndarray,
    onset_times: np.ndarray,
    onset_strengths: np.ndarray,
) -> tuple[float, np.ndarray, list[TempoCandidate]]:
    """배수 관계 tempo 오류를 보정하고 후보/신뢰도를 함께 반환한다."""
    if bpm <= 0 or onset_times.size < 8 or beat_times.size < 2:
        return bpm, beat_times, []

    evaluations = _tempo_evaluations(
        onset_env_raw, sr, hop, duration, bpm, beat_times, onset_times, onset_strengths
    )
    if not evaluations:
        return bpm, beat_times, []

    base = next((x for x in evaluations if abs(x[3] - 1.0) < 1e-9), evaluations[0])
    selected = base
    if base[0] > C.TEMPO_REFINE_GOOD_ENOUGH:
        # Normal correction: switch only when grid fit improves *and* strong-beat
        # evidence does not materially get worse. This avoids choosing a mathematically
        # neat but musically wrong multiple such as 128 -> ~86 BPM on dense 16ths.
        for candidate in sorted(evaluations, key=lambda x: x[0]):
            if (
                candidate[0] < base[0] - C.TEMPO_REFINE_MIN_IMPROVEMENT
                and candidate[4] >= base[4] - C.TEMPO_REFINE_MAX_ACCENT_DROP
            ):
                selected = candidate
                break

    # Half/double-tempo is special: a 75-BPM eighth grid can fit 150-BPM quarter attacks
    # perfectly, so a small grid-fit value alone is not sufficient evidence. This check runs
    # even when the base grid already looks "good".
    octave_candidates = [x for x in evaluations if abs(x[3] - 2.0) < 1e-9 or abs(x[3] - 0.5) < 1e-9]
    base_combined = base[0] - C.TEMPO_BEAT_ACCENT_WEIGHT * base[4]
    for candidate in octave_candidates:
        combined = candidate[0] - C.TEMPO_BEAT_ACCENT_WEIGHT * candidate[4]
        accent_gain = candidate[4] - base[4]
        if (
            accent_gain >= C.TEMPO_OCTAVE_ACCENT_GAIN
            and combined <= base_combined - C.TEMPO_OCTAVE_SELECTION_GAIN
        ):
            selected = candidate
            break

    candidates = _candidates_for_report(evaluations, selected[1])
    return float(selected[1]), np.asarray(selected[2], dtype=float), candidates


def refine_phase(beat_times: np.ndarray, onset_times: np.ndarray, onset_strengths: np.ndarray) -> np.ndarray:
    if beat_times.size < 2 or onset_times.size == 0:
        return beat_times
    interval = float(np.median(np.diff(beat_times)))
    w = onset_strengths**2 if onset_strengths.size == onset_times.size else np.ones_like(onset_times)
    tol = min(C.QUANTIZE_THRESHOLD_SEC, interval / 4 * C.QUANTIZE_MAX_FRACTION_OF_16TH)

    def score(beats: np.ndarray) -> float:
        idx = np.clip(np.searchsorted(beats, onset_times), 1, beats.size - 1)
        d = np.minimum(np.abs(onset_times - beats[idx - 1]), np.abs(onset_times - beats[idx]))
        return float(np.sum(w[d <= tol]))

    base = score(beat_times)
    best_shift, best_score = 0.0, base
    for k in (1, 2, 3):
        shift = k * interval / 4
        s = score(beat_times + shift)
        if s > best_score * C.PHASE_REFINE_MIN_GAIN:
            best_shift, best_score = shift, s
    if best_shift == 0.0:
        return beat_times
    shifted = beat_times + best_shift
    if shifted[0] - interval > 0:
        shifted = np.concatenate([[shifted[0] - interval], shifted])
    return shifted


def extract_features_from_signal(y: np.ndarray, sr: int) -> AudioFeatures:
    duration = float(len(y) / sr) if sr else 0.0
    rms_raw = librosa.feature.rms(y=y, hop_length=C.HOP_LENGTH)[0] if len(y) else np.array([0.0])
    rms_max_raw = float(rms_raw.max()) if rms_raw.size else 0.0

    if duration < C.MIN_AUDIO_DURATION_SEC:
        msg = f"오디오가 너무 짧습니다 ({duration:.2f}s < {C.MIN_AUDIO_DURATION_SEC}s). 빈 채보를 생성합니다."
        return _empty_features(sr, duration, rms_max_raw, msg)
    if rms_max_raw < C.SILENCE_RMS_THRESHOLD:
        return _empty_features(sr, duration, rms_max_raw, "무음 오디오로 판단되어 빈 채보를 생성합니다.")

    hop = C.HOP_LENGTH
    S = np.abs(librosa.stft(y, n_fft=C.N_FFT, hop_length=hop))
    freqs = librosa.fft_frequencies(sr=sr, n_fft=C.N_FFT)

    onset_env_raw = librosa.onset.onset_strength(y=y, sr=sr, hop_length=hop)
    onset_env = _normalize(onset_env_raw)
    rms_n = _normalize(rms_raw)
    onset_frames = librosa.onset.onset_detect(
        onset_envelope=onset_env_raw, sr=sr, hop_length=hop, units="frames"
    )
    onset_times = np.maximum(
        0.0, librosa.frames_to_time(onset_frames, sr=sr, hop_length=hop) - C.ONSET_LATENCY_COMP_SEC
    )

    tempo, beat_frames = librosa.beat.beat_track(onset_envelope=onset_env_raw, sr=sr, hop_length=hop)
    bpm = float(np.atleast_1d(tempo)[0])
    beat_times = librosa.frames_to_time(beat_frames, sr=sr, hop_length=hop)
    onset_strengths = onset_env[onset_frames] if len(onset_frames) else np.array([])
    # Tempo ambiguity is common in real mixes: a dense hi-hat can make 120 BPM look like
    # 180 BPM, while layered attacks can make 150 BPM look like 75 BPM. Weight tempo/grid
    # evidence by perceptual accent (transient strength + local RMS), not transient count alone.
    accents = (
        np.array(
            [
                C.ACCENT_W_STRENGTH * onset_env[f]
                + C.ACCENT_W_LOUDNESS * float(rms_n[f : f + 4].max())
                for f in onset_frames
            ]
        )
        if len(onset_frames)
        else np.array([])
    )
    bpm, beat_times, tempo_candidates = refine_tempo(
        onset_env_raw, sr, hop, duration, bpm, beat_times, onset_times, accents
    )

    beat_times = refine_phase(np.asarray(beat_times, dtype=float), onset_times, accents)

    n_frames = S.shape[1]
    rms = _normalize(rms_raw[:n_frames])
    centroid = librosa.feature.spectral_centroid(S=S, sr=sr)[0]

    band_onset: dict[str, np.ndarray] = {}
    band_energy: dict[str, np.ndarray] = {}
    for name, (lo, hi) in C.FREQUENCY_BANDS.items():
        mask = (freqs >= lo) & (freqs < hi)
        Sb = S[mask, :]
        if Sb.size == 0:
            band_onset[name] = np.zeros(n_frames)
            band_energy[name] = np.zeros(n_frames)
            continue
        band_energy[name] = _normalize(Sb.sum(axis=0))
        env = librosa.onset.onset_strength(
            S=librosa.power_to_db(Sb**2, ref=np.max), sr=sr, hop_length=hop
        )
        band_onset[name] = _normalize(env[:n_frames])

    warnings: list[str] = []
    if len(beat_times) < 2:
        warnings.append("beat를 충분히 검출하지 못했습니다. grid quantize가 제한됩니다.")
    if len(onset_frames) == 0:
        warnings.append("onset이 검출되지 않았습니다.")
    if tempo_candidates:
        selected = next((x for x in tempo_candidates if x.selected), None)
        if selected and selected.confidence < 0.45:
            warnings.append("BPM 후보 간 차이가 작아 tempo 신뢰도가 낮습니다.")

    return AudioFeatures(
        sr=sr,
        hop_length=hop,
        duration=duration,
        bpm=bpm,
        beat_times=np.asarray(beat_times, dtype=float),
        onset_frames=np.asarray(onset_frames, dtype=int),
        onset_times=np.asarray(onset_times, dtype=float),
        onset_env=onset_env,
        rms=rms,
        rms_max_raw=rms_max_raw,
        spectral_centroid=centroid,
        band_onset=band_onset,
        band_energy=band_energy,
        tempo_candidates=tempo_candidates,
        warnings=warnings,
    )


def extract_features(path: str) -> AudioFeatures:
    y, sr = load_audio(path)
    return extract_features_from_signal(y, sr)
