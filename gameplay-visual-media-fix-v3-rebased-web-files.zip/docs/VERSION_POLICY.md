# BEATDASH::Revive version policy

- Internal development name: BEATDASH::Revive.
- Public app name: BEATDASH (web, Android, page title, API docs).
- Current target: v3.0.0. Review candidate; Android build and device validation are pending.
- Bundle planned changes per version. After v3.0 acceptance, proceed to v3.1, then v3.2.
- Completion requires planned features, passing tests/builds, migration checks and device readiness.
- Preserve Android applicationId `com.rhythmlab.companion`, signing identity, saved song layout,
  and existing localStorage keys. Naming changes must not reset user data.
- v3.0 uses Perfect 35ms / Great 75ms / Good 120ms (inclusive boundaries), Hold release 120ms,
  and Hold regrab 100ms. After pause, an active hold requires re-pressing within the grace window.
- No feature work for v3.1 has started in this review.
