# AI Rhythm Lab v0.4 Companion MVP bundle

This bundle contains two pieces:

- `android-companion/`: Android/Kotlin app. It receives a YouTube share link, extracts temporary audio on-device, uploads it to the existing Railway analyzer, then opens the web player.
- `PROTOCOL.md`: handoff contract used between the app and web player.

A separate web deployment package is provided as `rhythm-core-v0.4-companion-mvp.zip` and as a same-name replacement `rhythm-core-v0.3.1-youtube-input.zip` so the current root Railway Dockerfile does not need another edit.

## Intended MVP flow

YouTube Share → Companion → device-side audio extraction → `/api/analyze` → `/?session=...&videoId=...` → audio-clock gameplay + muted YouTube MV background.

The Android project includes a GitHub Actions workflow that builds a debug APK without needing Android Studio on a PC.
