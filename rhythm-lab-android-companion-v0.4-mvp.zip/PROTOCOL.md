# Companion ↔ Web protocol (v0.4)

## Upload

`POST /api/analyze` multipart form:

- `file`: extracted audio (M4A preferred)
- `difficulty`: easy | normal | hard | expert
- `seed`: 32-bit integer

Existing server response is reused. Companion only needs the `id` field.

## Browser handoff

`/?session=<analysis-id>&videoId=<youtube-video-id>`

Web behavior:

1. `GET /api/session/<analysis-id>`
2. Show analysis summary.
3. Play the server-hosted extracted audio as the authoritative game clock.
4. Render YouTube IFrame Player muted as the visual MV.
5. On START / pause / restart, mirror control to the iframe.
6. Periodically correct iframe drift against `audio.currentTime`.

This avoids downloading YouTube media from the Railway datacenter entirely.
