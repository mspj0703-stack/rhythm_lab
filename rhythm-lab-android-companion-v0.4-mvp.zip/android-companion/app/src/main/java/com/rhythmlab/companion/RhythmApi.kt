package com.rhythmlab.companion

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

object RhythmApi {
    const val WEB_BASE = "https://web-production-e18dd.up.railway.app"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.MINUTES)
        .writeTimeout(8, TimeUnit.MINUTES)
        .callTimeout(10, TimeUnit.MINUTES)
        .build()

    data class Result(val analysisId: String)

    fun analyze(file: File, difficulty: String, seed: Int): Result {
        val mediaType = "audio/mp4".toMediaType()
        val multipart = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("file", file.name, file.asRequestBody(mediaType))
            .addFormDataPart("difficulty", difficulty.lowercase().toRequestBody())
            .addFormDataPart("seed", seed.toString().toRequestBody())
            .build()

        val request = Request.Builder()
            .url("$WEB_BASE/api/analyze")
            .post(multipart)
            .build()

        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail = runCatching { JSONObject(body).optString("detail") }.getOrNull()
                error(detail?.takeIf { it.isNotBlank() } ?: "서버 분석 실패 (${response.code})")
            }
            val json = JSONObject(body)
            return Result(json.getString("id"))
        }
    }
}
