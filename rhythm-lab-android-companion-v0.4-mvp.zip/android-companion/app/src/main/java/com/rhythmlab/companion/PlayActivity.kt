package com.rhythmlab.companion

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.ByteArrayInputStream
import java.io.FileInputStream
import java.io.InputStream

/** Plays the existing web game inside the app, serving saved sessions from private app storage. */
class PlayActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private lateinit var store: SavedSongStore
    private lateinit var songId: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = SavedSongStore(this)
        songId = intent.getStringExtra(EXTRA_SONG_ID).orEmpty()
        val song = store.list().firstOrNull { it.id == songId }
        if (song == null) { finish(); return }

        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.settings.allowFileAccess = false
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (!request.isForMainFrame || request.url.host == Uri.parse(RhythmApi.WEB_BASE).host) return false
                startActivity(Intent(Intent.ACTION_VIEW, request.url))
                return true
            }

            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val url = request.url
                if (url.scheme != "https" || url.host != Uri.parse(RhythmApi.WEB_BASE).host || request.method != "GET") return null
                return when (url.path) {
                    "/api/session/$songId" -> fileResponse(store.session(songId), "application/json", request)
                    "/api/media/$songId" -> fileResponse(store.audio(songId), "audio/wav", request)
                    else -> null
                }
            }
        }

        val url = "${RhythmApi.WEB_BASE}/?session=${Uri.encode(song.id)}&videoId=${Uri.encode(song.videoId)}&saved=1"
        webView.loadUrl(url)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { finish() }
        })
    }

    private fun fileResponse(file: File, mime: String, request: WebResourceRequest): WebResourceResponse {
        if (!file.isFile) return WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", emptyMap(), "Not Found".byteInputStream())
        val size = file.length()
        val range = request.requestHeaders["Range"]
        val match = Regex("bytes=(\\d+)-(\\d*)").matchEntire(range.orEmpty())
        val start = match?.groupValues?.get(1)?.toLongOrNull() ?: 0L
        val end = match?.groupValues?.get(2)?.takeIf { it.isNotEmpty() }?.toLongOrNull()?.coerceAtMost(size - 1) ?: size - 1
        if (start >= size || end < start) {
            return WebResourceResponse(mime, null, 416, "Range Not Satisfiable", mapOf("Content-Range" to "bytes */$size"), ByteArrayInputStream(byteArrayOf()))
        }
        val length = end - start + 1
        val stream = FileInputStream(file)
        stream.channel.position(start)
        val headers = mutableMapOf("Accept-Ranges" to "bytes", "Content-Length" to length.toString())
        if (match != null) headers["Content-Range"] = "bytes $start-$end/$size"
        return WebResourceResponse(mime, null, if (match != null) 206 else 200,
            if (match != null) "Partial Content" else "OK", headers, LimitedStream(stream, length))
    }

    private class LimitedStream(private val source: InputStream, private var left: Long) : InputStream() {
        override fun read(): Int {
            if (left <= 0) return -1
            val value = source.read()
            if (value >= 0) left--
            return value
        }
        override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
            if (left <= 0) return -1
            val count = source.read(buffer, offset, minOf(length.toLong(), left).toInt())
            if (count > 0) left -= count
            return count
        }
        override fun close() = source.close()
    }

    override fun onPause() {
        if (::webView.isInitialized) webView.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (::webView.isInitialized) webView.onResume()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }

    companion object { const val EXTRA_SONG_ID = "song_id" }
}
