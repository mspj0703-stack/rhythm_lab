package com.rhythmlab.companion

import android.content.Context
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File

object YoutubeEngine {
    private var initialized = false

    @Synchronized
    fun ensureInitialized(context: Context, status: (String) -> Unit) {
        if (initialized) return
        status("yt-dlp 엔진 초기화 중…")
        YoutubeDL.getInstance().init(context.applicationContext)
        FFmpeg.getInstance().init(context.applicationContext)
        initialized = true

        // YouTube extractor changes frequently. Updating is best-effort only;
        // a bundled version still remains available if GitHub is unreachable.
        runCatching {
            status("yt-dlp 최신 버전 확인 중…")
            YoutubeDL.getInstance().updateYoutubeDL(
                context.applicationContext,
                YoutubeDL.UpdateChannel.NIGHTLY,
            )
        }
    }

    fun extractAudio(
        context: Context,
        url: String,
        onProgress: (Int, String) -> Unit,
    ): File {
        ensureInitialized(context) { onProgress(1, it) }

        val dir = File(context.cacheDir, "rhythm_extract").apply {
            mkdirs()
            listFiles()?.forEach { it.delete() }
        }

        val request = YoutubeDLRequest(url).apply {
            addOption("--no-playlist")
            addOption("--no-warnings")
            addOption("--match-filter", "duration <= 480")
            addOption("--max-filesize", "80M")
            addOption("-f", "bestaudio/best")
            addOption("-x")
            addOption("--audio-format", "wav")
            addOption("--postprocessor-args", "ExtractAudio+ffmpeg_o:-ac 1 -ar 22050 -c:a pcm_s16le")
            addOption("--audio-quality", "5")
            addOption("--no-mtime")
            addOption("-o", File(dir, "source.%(ext)s").absolutePath)
        }

        val processId = "rhythm-lab-${System.currentTimeMillis()}"
        YoutubeDL.getInstance().execute(request, processId) { progress, eta, line ->
            val p = progress.toInt().coerceIn(0, 100)
            val suffix = if (eta > 0) " · ${eta}s 남음" else ""
            val phase = when {
                line.contains("ExtractAudio", ignoreCase = true) -> "오디오 변환 중…"
                p > 0 -> "YouTube에서 오디오 받는 중 $p%$suffix"
                else -> "YouTube 정보 확인 중…"
            }
            onProgress(p.coerceAtMost(95), phase)
        }

        val result = dir.listFiles()
            ?.filter { it.isFile && it.length() > 0 }
            ?.maxByOrNull { it.lastModified() }
            ?: error("추출된 오디오 파일을 찾지 못했습니다.")

        onProgress(100, "오디오 준비 완료")
        return result
    }
}
