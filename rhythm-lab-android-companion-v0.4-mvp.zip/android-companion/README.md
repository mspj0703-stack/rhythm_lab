# Rhythm Lab Companion v0.4 MVP

Android companion for AI Rhythm Lab.

## Flow

1. Paste a public YouTube URL, or use **YouTube → Share → Rhythm Lab Companion**.
2. The app runs yt-dlp on the Android device and extracts temporary 22050 Hz mono WAV audio.
3. It uploads the audio to `https://web-production-e18dd.up.railway.app/api/analyze`.
4. The server returns an analysis/session ID.
5. The app opens the web tester with `?session=<id>&videoId=<YouTube ID>`.
6. The web app uses uploaded audio as the authoritative timing clock and the YouTube iframe as the MV background.
7. The local temporary audio file is deleted after upload.

## Build without a PC

The repository's `build-android-companion4.yml` workflow builds a signed `app-release.apk` from a persistent signing key stored in GitHub Actions secrets. Set `COMPANION_KEYSTORE_BASE64` and `COMPANION_KEYSTORE_PASSWORD` before running it. Keep a backup of the keystore and password: losing them means future APKs cannot update installed copies. The workflow sets an increasing version code on each run. Existing APKs built with an ephemeral debug key require one uninstall before installing the first signed release; later signed releases install as updates.

## Dependencies

- `io.github.junkfood02.youtubedl-android:library:0.18.1`
- `io.github.junkfood02.youtubedl-android:ffmpeg:0.18.1`
- OkHttp 4.12.0

## Current MVP limits

- Public YouTube videos only.
- Region/age/DRM restrictions can still fail.
- YouTube can change extraction behavior; the app performs a best-effort NIGHTLY yt-dlp update during first use.
- This project is for development/testing. Respect content rights and service terms when using media.
