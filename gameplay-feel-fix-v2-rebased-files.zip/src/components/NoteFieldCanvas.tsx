import { useEffect, useRef } from "react";
import type { NoteRuntime } from "../types/chart";
import { computeNoteY, computeHoldTailLengthPx } from "../engine/renderer";

interface Props {
  notes: NoteRuntime[];
  currentTimeSec: number;
  width: number;
  height: number;
  judgeLineY: number;
  laneCount: number;
  noteSpeed: number;
}

const LANE_COLORS = ["#8f82ff", "#4ce0b1", "#ff845e", "#ff6ca5"];

function roundedRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.lineTo(x + w - rr, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + rr);
  ctx.lineTo(x + w, y + h - rr);
  ctx.quadraticCurveTo(x + w, y + h, x + w - rr, y + h);
  ctx.lineTo(x + rr, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - rr);
  ctx.lineTo(x, y + rr);
  ctx.quadraticCurveTo(x, y, x + rr, y);
  ctx.closePath();
  ctx.fill();
}

/** v2 노트 렌더링: 빠른 속도에서도 head/tail/type을 한눈에 읽을 수 있게 한다. */
export function NoteFieldCanvas({ notes, currentTimeSec, width, height, judgeLineY, laneCount, noteSpeed }: Props) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    ctx.clearRect(0, 0, width, height);
    const laneWidth = width / laneCount;

    ctx.fillStyle = "rgba(4, 4, 10, 0.19)";
    ctx.fillRect(0, 0, width, height);
    ctx.strokeStyle = "rgba(255,255,255,0.13)";
    for (let i = 1; i < laneCount; i++) {
      ctx.beginPath();
      ctx.moveTo(i * laneWidth, 0);
      ctx.lineTo(i * laneWidth, height);
      ctx.stroke();
    }

    ctx.save();
    ctx.shadowBlur = 18;
    ctx.shadowColor = "rgba(220,205,255,0.8)";
    ctx.strokeStyle = "rgba(255,255,255,0.96)";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(0, judgeLineY);
    ctx.lineTo(width, judgeLineY);
    ctx.stroke();
    ctx.restore();

    for (const n of notes) {
      if (n.status !== "pending" && n.status !== "holding") continue;
      const x = n.note.lane * laneWidth + laneWidth * 0.055;
      const noteWidth = laneWidth * 0.89;
      const y = computeNoteY(n.note.time, currentTimeSec, judgeLineY, noteSpeed);
      const laneColor = LANE_COLORS[n.note.lane % LANE_COLORS.length];

      ctx.shadowColor = laneColor;
      ctx.shadowBlur = n.status === "holding" ? 22 : 14;

      if (n.note.type === "hold") {
        const tailLen = computeHoldTailLengthPx(n.note.duration, judgeLineY, noteSpeed);
        const rawTop = y - tailLen;
        const headY = n.status === "holding" ? judgeLineY : y;
        const top = rawTop;
        const bottom = Math.min(headY, judgeLineY);

        const grad = ctx.createLinearGradient(0, top, 0, Math.max(top + 1, bottom));
        grad.addColorStop(0, `${laneColor}55`);
        grad.addColorStop(1, `${laneColor}cc`);
        ctx.fillStyle = grad;
        ctx.globalAlpha = n.status === "holding" ? 0.95 : 0.72;
        roundedRect(ctx, x + noteWidth * 0.08, top, noteWidth * 0.84, Math.max(bottom - top, 7), 6);
        ctx.globalAlpha = 1;

        ctx.fillStyle = "rgba(255,255,255,.92)";
        roundedRect(ctx, x + noteWidth * 0.06, top - 3, noteWidth * 0.88, 7, 4);

        ctx.fillStyle = laneColor;
        roundedRect(ctx, x, headY - 10, noteWidth, 20, 7);
        ctx.fillStyle = "rgba(255,255,255,.86)";
        roundedRect(ctx, x + 5, headY + 4, noteWidth - 10, 3, 2);
      } else {
        ctx.fillStyle = laneColor;
        roundedRect(ctx, x, y - 10, noteWidth, 20, 7);
        ctx.fillStyle = "rgba(255,255,255,.88)";
        roundedRect(ctx, x + 5, y + 4, noteWidth - 10, 3, 2);

        if (n.note.type === "flick") {
          ctx.strokeStyle = "white";
          ctx.lineWidth = 4;
          ctx.lineCap = "round";
          const cx = x + noteWidth / 2;
          ctx.beginPath();
          ctx.moveTo(cx - 11, y + 2);
          ctx.lineTo(cx, y - 8);
          ctx.lineTo(cx + 11, y + 2);
          ctx.stroke();
        }
      }
      ctx.shadowBlur = 0;
    }
  }, [notes, currentTimeSec, width, height, judgeLineY, laneCount, noteSpeed]);

  return <canvas ref={canvasRef} width={width} height={height} style={{ display: "block", width: "100%", height: "100%" }} />;
}
