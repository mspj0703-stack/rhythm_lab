import { NOTE_FALL_TIME_SEC } from "../constants/config";

export const NOTE_SPEED_MIN = 1.0;
export const NOTE_SPEED_MAX = 10.0;
export const NOTE_SPEED_STEP = 0.1;
export const DEFAULT_NOTE_SPEED = 6.0;
export const NOTE_SPEED_STORAGE_KEY = "rhythm-lab.note-speed.v1";

export function normalizeNoteSpeed(value: number): number {
  if (!Number.isFinite(value)) return DEFAULT_NOTE_SPEED;
  const clamped = Math.min(NOTE_SPEED_MAX, Math.max(NOTE_SPEED_MIN, value));
  return Math.round(clamped / NOTE_SPEED_STEP) * NOTE_SPEED_STEP;
}

/**
 * 숫자형 노트 속도를 실제 화면 체류 시간으로 바꾼다.
 * 6.0에서는 기존 NOTE_FALL_TIME_SEC(1.6초)를 그대로 유지한다.
 * 속도가 커질수록 같은 시간 차이가 더 큰 화면 거리로 보이지만,
 * chart time / media.currentTime / 판정 시각은 전혀 바꾸지 않는다.
 */
export function getNoteFallTimeSec(noteSpeed: number): number {
  const speed = normalizeNoteSpeed(noteSpeed);
  return NOTE_FALL_TIME_SEC * (DEFAULT_NOTE_SPEED / speed);
}

export function getActiveWindowSec(noteSpeed: number): number {
  return getNoteFallTimeSec(noteSpeed) + 0.5;
}

export function loadNoteSpeed(storage?: Pick<Storage, "getItem"> | null): number {
  const target = storage ?? (typeof window !== "undefined" ? window.localStorage : null);
  if (!target) return DEFAULT_NOTE_SPEED;
  try {
    const raw = target.getItem(NOTE_SPEED_STORAGE_KEY);
    if (raw === null) return DEFAULT_NOTE_SPEED;
    return normalizeNoteSpeed(Number(raw));
  } catch {
    return DEFAULT_NOTE_SPEED;
  }
}

export function saveNoteSpeed(noteSpeed: number, storage?: Pick<Storage, "setItem"> | null): void {
  const target = storage ?? (typeof window !== "undefined" ? window.localStorage : null);
  if (!target) return;
  try {
    target.setItem(NOTE_SPEED_STORAGE_KEY, normalizeNoteSpeed(noteSpeed).toFixed(1));
  } catch {
    // localStorage가 차단된 환경에서는 세션 값만 사용한다.
  }
}
