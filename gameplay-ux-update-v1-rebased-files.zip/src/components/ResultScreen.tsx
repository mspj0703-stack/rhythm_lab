import type { GameResult } from "../engine/resultCalculation";

interface Props {
  result: GameResult;
  onRestart: () => void;
}

export function ResultScreen({ result, onRestart }: Props) {
  const fullCombo = result.miss === 0;

  return (
    <section className="result-screen" aria-label="플레이 결과">
      <div className="result-heading">
        <div>
          <span className="eyebrow">RESULT</span>
          <h2>{fullCombo ? "FULL COMBO" : "TRACK COMPLETE"}</h2>
        </div>
        <div className={`result-rank rank-${result.rank.toLowerCase()}`}>{result.rank}</div>
      </div>

      <div className="result-score-block">
        <span>SCORE</span>
        <strong>{result.score.toLocaleString()}</strong>
      </div>

      <div className="result-grid">
        <div><span className="label">Accuracy</span><span className="value">{result.accuracyPercent.toFixed(2)}%</span></div>
        <div><span className="label">Max Combo</span><span className="value">{result.maxCombo.toLocaleString()}</span></div>
      </div>

      <div className="result-counts">
        <div><span className="perfect">Perfect</span><strong>{result.perfect}</strong></div>
        <div><span className="great">Great</span><strong>{result.great}</strong></div>
        <div><span className="good">Good</span><strong>{result.good}</strong></div>
        <div><span className="miss">Miss</span><strong>{result.miss}</strong></div>
      </div>

      <div className="result-buttons">
        <button className="primary-result-action" onClick={onRestart}>RETRY</button>
      </div>
    </section>
  );
}
