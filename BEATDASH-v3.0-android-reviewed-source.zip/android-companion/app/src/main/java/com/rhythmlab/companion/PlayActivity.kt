package com.rhythmlab.companion

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.ByteArrayInputStream
import java.io.FileInputStream
import java.io.InputStream

/** Plays the existing web game inside the app, serving saved sessions from private app storage. */
class PlayActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private lateinit var store: SavedSongStore
    private lateinit var songId: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = SavedSongStore(this)
        songId = intent.getStringExtra(EXTRA_SONG_ID).orEmpty()
        val song = store.list().firstOrNull { it.id == songId }
        if (song == null) { finish(); return }

        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.settings.allowFileAccess = false
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (!request.isForMainFrame || request.url.host == Uri.parse(RhythmApi.WEB_BASE).host) return false
                startActivity(Intent(Intent.ACTION_VIEW, request.url))
                return true
            }

            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val url = request.url
                if (url.scheme != "https" || url.host != Uri.parse(RhythmApi.WEB_BASE).host || request.method !in setOf("GET", "HEAD")) return null
                return when (url.path) {
                    "/api/session/$songId" -> fileResponse(store.session(songId), "application/json", request)
                    "/api/media/$songId" -> fileResponse(store.audio(songId), "audio/wav", request)
                    "/api/video/$songId" -> fileResponse(store.video(songId), "video/mp4", request)
                    else -> null
                }
            }
        }

        val url = "${RhythmApi.WEB_BASE}/?session=${Uri.encode(song.id)}&saved=1"
        webView.loadUrl(url)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { finish() }
        })
    }

    private fun fileResponse(file: File, mime: String, request: WebResourceRequest): WebResourceResponse {
        if (!file.isFile) return WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", emptyMap(), "Not Found".byteInputStream())
        val size = file.length()
        val rangeHeader = request.requestHeaders.entries.firstOrNull { it.key.equals("Range", true) }?.value
        val range = rangeHeader?.let { ByteRange.parse(it, size) }
        if (rangeHeader != null && range == null) {
            return WebResourceResponse(mime, null, 416, "Range Not Satisfiable",
                mapOf("Content-Range" to "bytes */$size", "Cache-Control" to "no-store"), ByteArrayInputStream(byteArrayOf()))
        }
        val start = range?.start ?: 0L
        val end = range?.end ?: (size - 1)
        val length = end - start + 1
        val stream = FileInputStream(file)
        stream.channel.position(start)
        val headers = mutableMapOf("Accept-Ranges" to "bytes", "Content-Length" to length.toString(), "Cache-Control" to "no-store")
        if (range != null) headers["Content-Range"] = "bytes $start-$end/$size"
        return WebResourceResponse(mime, null, if (range != null) 206 else 200,
            if (range != null) "Partial Content" else "OK", headers, if (request.method == "HEAD") { stream.close(); ByteArrayInputStream(byteArrayOf()) } else LimitedStream(stream, length))
    }

    private class LimitedStream(private val source: InputStream, private var left: Long) : InputStream() {
        override fun read(): Int {
            if (left <= 0) return -1
            val value = source.read()
            if (value >= 0) left--
            return value
        }
        override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
            if (length == 0) return 0
            if (left <= 0) return -1
            val count = source.read(buffer, offset, minOf(length.toLong(), left).toInt())
            if (count > 0) left -= count
            return count
        }
        override fun close() = source.close()
    }

    override fun onPause() {
        if (::webView.isInitialized) {
            webView.evaluateJavascript("window.dispatchEvent(new Event('beatdash:pause')); document.querySelectorAll('audio,video').forEach(m => m.pause());", null)
            webView.onPause()
        }
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (::webView.isInitialized) webView.onResume()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }

    companion object { const val EXTRA_SONG_ID = "song_id" }
}
